#!/bin/bash

while true; do
	lua bot.lua
	sleep 10s
done
